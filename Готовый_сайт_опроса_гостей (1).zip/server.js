const express = require("express");
const Database = require("better-sqlite3");
const QRCode = require("qrcode");
const path = require("path");

const app = express();
const port = process.env.PORT || 3000;
const adminUser = process.env.ADMIN_USER || "admin";
const adminPassword = process.env.ADMIN_PASSWORD || "change-me-now";
const publicUrl = (process.env.PUBLIC_URL || `http://localhost:${port}`).replace(/\/$/, "");

const db = new Database("survey.db");
db.pragma("journal_mode = WAL");
db.exec(`
CREATE TABLE IF NOT EXISTS responses (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  created_at TEXT NOT NULL DEFAULT (datetime('now')),
  visit_frequency TEXT,
  service_attitude TEXT,
  current_rating INTEGER,
  price_10 TEXT,
  priority TEXT,
  benefits TEXT,
  concerns TEXT,
  preferred_cases TEXT,
  comment TEXT
)`);

app.use(express.json({limit:"100kb"}));
app.use(express.static(path.join(__dirname, "public")));

function auth(req,res,next){
  const h=req.headers.authorization||"";
  if(!h.startsWith("Basic ")){res.set("WWW-Authenticate",'Basic realm="Admin"'); return res.status(401).send("Авторизация требуется");}
  const [u,p]=Buffer.from(h.slice(6),"base64").toString().split(":");
  if(u!==adminUser || p!==adminPassword) return res.status(403).send("Доступ запрещён");
  next();
}

app.post("/api/responses",(req,res)=>{
  const x=req.body||{};
  const stmt=db.prepare(`INSERT INTO responses
    (visit_frequency,service_attitude,current_rating,price_10,priority,benefits,concerns,preferred_cases,comment)
    VALUES (?,?,?,?,?,?,?,?,?)`);
  const result=stmt.run(
    x.visit_frequency||"", x.service_attitude||"", Number(x.current_rating)||null,
    x.price_10||"", x.priority||"", JSON.stringify(x.benefits||[]),
    JSON.stringify(x.concerns||[]), JSON.stringify(x.preferred_cases||[]), x.comment||""
  );
  res.json({ok:true,id:result.lastInsertRowid});
});

app.get("/api/analytics",auth,(req,res)=>{
  const rows=db.prepare("SELECT * FROM responses ORDER BY id DESC").all();
  const count=(field,val)=>rows.filter(r=>r[field]===val).length;
  const pct=(n,d)=>d?Math.round(n/d*1000)/10:0;
  const positiveService=count("service_attitude","Определённо положительно")+count("service_attitude","Скорее положительно");
  const acceptable10=count("price_10","Для меня приемлемо")+count("price_10","Скорее приемлемо");
  const avg=rows.filter(r=>r.current_rating).reduce((s,r)=>s+r.current_rating,0)/(rows.filter(r=>r.current_rating).length||1);
  const multi=(field)=>{const m={}; rows.forEach(r=>{let a=[];try{a=JSON.parse(r[field]||"[]")}catch{};a.forEach(v=>m[v]=(m[v]||0)+1)});return m};
  res.json({
    total:rows.length,
    servicePositive:pct(positiveService,rows.length),
    acceptable10:pct(acceptable10,rows.length),
    avgRating:Math.round(avg*10)/10,
    serviceAttitude:["Определённо положительно","Скорее положительно","Нейтрально","Скорее отрицательно","Определённо отрицательно","Мне сложно ответить"].map(v=>({label:v,count:count("service_attitude",v)})),
    price10:["Для меня приемлемо","Скорее приемлемо","Зависит от качества обслуживания","Скорее неприемлемо","Совершенно неприемлемо","Затрудняюсь ответить"].map(v=>({label:v,count:count("price_10",v)})),
    benefits:multi("benefits"), concerns:multi("concerns"), priority:multi("priority"),
    rows
  });
});

app.get("/api/qr",async(req,res)=>{
  const target=publicUrl+"/";
  res.type("image/png").send(await QRCode.toBuffer(target,{errorCorrectionLevel:"M",width:900,margin:2}));
});

app.get("/admin",(req,res)=>res.sendFile(path.join(__dirname,"public","admin.html")));
app.listen(port,()=>console.log(`Survey site: ${publicUrl}`));