const express=require("express");
const Database=require("better-sqlite3");
const QRCode=require("qrcode");
const path=require("path");
const app=express(), PORT=process.env.PORT||3000;
const USER=process.env.ADMIN_USER||"admin", PASS=process.env.ADMIN_PASSWORD||"change-me-now";
const PUBLIC_URL=(process.env.PUBLIC_URL||"").replace(/\/$/,"");
const db=new Database("survey.db");
db.pragma("journal_mode=WAL");
db.exec(`CREATE TABLE IF NOT EXISTS responses(
id INTEGER PRIMARY KEY AUTOINCREMENT,created_at TEXT NOT NULL DEFAULT(datetime('now')),
visit_frequency TEXT,service_attitude TEXT,current_rating INTEGER,price_10 TEXT,priority TEXT,
benefits TEXT,concerns TEXT,preferred_cases TEXT,comment TEXT)`);
app.use(express.json({limit:"100kb"})); app.use(express.static(path.join(__dirname)));
function auth(req,res,next){const h=req.headers.authorization||"";if(!h.startsWith("Basic ")){res.set("WWW-Authenticate",'Basic realm="Admin"');return res.status(401).send("Требуется вход.");}const s=Buffer.from(h.slice(6),"base64").toString(),i=s.indexOf(":");if((i<0?"":s.slice(0,i))!==USER||(i<0?"":s.slice(i+1))!==PASS)return res.status(403).send("Доступ запрещён.");next()}
const arr=v=>Array.isArray(v)?v.filter(x=>typeof x==="string").slice(0,30):[];
app.post("/api/responses",(req,res)=>{const x=req.body||{};const r=db.prepare(`INSERT INTO responses(visit_frequency,service_attitude,current_rating,price_10,priority,benefits,concerns,preferred_cases,comment) VALUES(?,?,?,?,?,?,?,?,?)`).run(String(x.visit_frequency||""),String(x.service_attitude||""),Number(x.current_rating)||null,String(x.price_10||""),String(x.priority||""),JSON.stringify(arr(x.benefits)),JSON.stringify(arr(x.concerns)),JSON.stringify(arr(x.preferred_cases)),String(x.comment||"").slice(0,2000));res.json({ok:true,id:r.lastInsertRowid})});
app.get("/api/analytics",auth,(req,res)=>{const rows=db.prepare("SELECT * FROM responses ORDER BY id DESC").all(),count=(f,v)=>rows.filter(r=>r[f]===v).length,pct=(n,d)=>d?Math.round(n/d*1000)/10:0;const pos=count("service_attitude","Определённо положительно")+count("service_attitude","Скорее положительно"),acc=count("price_10","Для меня приемлемо")+count("price_10","Скорее приемлемо"),rated=rows.filter(r=>r.current_rating),avg=rated.length?Math.round(rated.reduce((s,r)=>s+Number(r.current_rating),0)/rated.length*10)/10:0;const multi=f=>{const m={};rows.forEach(r=>{let a=[];try{a=JSON.parse(r[f]||"[]")}catch{}a.forEach(v=>m[v]=(m[v]||0)+1)});return m};res.json({total:rows.length,servicePositive:pct(pos,rows.length),acceptable10:pct(acc,rows.length),avgRating:avg,serviceAttitude:["Определённо положительно","Скорее положительно","Нейтрально","Скорее отрицательно","Определённо отрицательно","Мне сложно ответить"].map(label=>({label,count:count("service_attitude",label)})),price10:["Для меня приемлемо","Скорее приемлемо","Зависит от качества обслуживания","Скорее неприемлемо","Совершенно неприемлемо","Затрудняюсь ответить"].map(label=>({label,count:count("price_10",label)})),benefits:multi("benefits"),concerns:multi("concerns"),priority:multi("priority"),rows:rows.slice(0,100)})});
app.get("/api/qr",async(req,res)=>{const target=(PUBLIC_URL||`${req.protocol}://${req.get("host")}`)+"/";res.type("image/png").send(await QRCode.toBuffer(target,{errorCorrectionLevel:"M",width:900,margin:2}))});
app.get("/admin",auth,(req,res)=>res.sendFile(path.join(__dirname,"admin.html")));app.get("/health",(req,res)=>res.json({ok:true}));
app.listen(PORT,"0.0.0.0",()=>console.log("Guest survey running on "+PORT));